# users/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from .views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', base, name='base'),
    
    path('signup/', register_view, name='signup'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),

    path('dashboard/', dashboard, name='dashboard'),
    
    path('summary/', summary_view, name='summary_view'),
    path('distribution/', sentiment_distribution_view, name='sentiment_distribution'),
    path('trend/', sentiment_trend_view, name='sentiment_trend'),
    path('health-terms/', health_terms_view, name='health_terms'),
    path('health_insight_dashboard/', health_insight_dashboard, name='health_insight_dashboard'),
    
    path("classify/",classify_text, name="classify_text"),

    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

