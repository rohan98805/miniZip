from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.conf import settings
from django.contrib.auth import get_user_model

from .forms import *
from .models import *
User = get_user_model()  # Unified user reference

# Base view
def base(request):
    return render(request, 'base.html')

# Signup view
def signup_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('bloom_question_view')
        else:
            return render(request, 'registration/signup.html', {'form': form})
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

# Logout view
def logout_view(request):
    logout(request)
    return redirect('login')

# Profile view
@login_required
def profile_view(request):
    return render(request, 'account/profile.html', {'user': request.user})

# Edit profile view
@login_required
def edit_profile(request):
    user = request.user
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = ProfileForm(instance=user)
    return render(request, 'account/edit_profile.html', {'form': form})

# List other users for chat
@login_required
def user_list_view(request):
    users = User.objects.exclude(id=request.user.id)
    return render(request, 'users/user_list.html', {'users': users})

# Chat between two users
@login_required
def chat_view_by_id(request, user_id):
    other_user = get_object_or_404(User, id=user_id)
    messages = Message.objects.filter(
        (Q(sender=request.user) & Q(receiver=other_user)) |
        (Q(sender=other_user) & Q(receiver=request.user))
    ).order_by('timestamp')

    if request.method == 'POST':
        text = request.POST.get('text')
        image = request.FILES.get('image')
        Message.objects.create(sender=request.user, receiver=other_user, text=text, image=image)
        return redirect('chat', user_id=other_user.id)

    return render(request, 'users/chat.html', {
        'messages': messages,
        'receiver': other_user
    })

# views.py
from django.shortcuts import render
from .utils import predict_bloom_level, extract_features, give_feedback, generate_nlp_answer

def analyze_question(request):
    context = {}
    if request.method == 'POST':
        question = request.POST.get('question')
        domain = request.POST.get('domain') or "General"

        predicted_level = predict_bloom_level(question)
        features = extract_features(question)
        feedback = give_feedback(features, predicted_level, domain)
        answer = generate_nlp_answer(question, predicted_level, domain)

        context = {
            "question": question,
            "predicted_level": predicted_level,
            "feedback": feedback,
            "answer": answer,
            "features": features
        }

    return render(request, 'dashboard/dashboard.html', context)


from django.shortcuts import render
from .models import QuestionAnalysis
from .bloom_model import predict_bloom_level, extract_features, give_feedback, generate_nlp_answer
# views.py
import matplotlib
matplotlib.use('Agg')  # Use non-GUI backend
import matplotlib.pyplot as plt
from io import BytesIO
import base64
from django.shortcuts import render
from .forms import QuestionForm
from .models import QuestionAnalysis
from .nlp_utils import predict_bloom_level, extract_features, give_feedback, generate_nlp_answer


from django.shortcuts import render
from .models import QuestionAnalysis
from .bloom_model import predict_bloom_level, extract_features, give_feedback, generate_nlp_answer

def bloom_question_view(request):
    context = {}

    if request.method == 'POST':
        question = request.POST.get('question', '').strip()
        if question:
            predicted_level = predict_bloom_level(question)
            features = extract_features(question)
            feedback = give_feedback(features, predicted_level)
            answer_dict = generate_nlp_answer(question)

            # Save to DB
            analysis = QuestionAnalysis.objects.create(
                question_text=question,
                predicted_level=predicted_level,
                suggested_level=features["suggested_level"],
                matched_verbs=", ".join(features["verbs"]),
                tokens=", ".join(features["tokens"]),
                feedback=feedback,
                generated_answer=answer_dict["answer"]
            )

            context = {
                "question": question,
                "predicted_level": predicted_level,
                "tokens": features["tokens"],
                "matched_verbs": features["verbs"],
                "suggested_level": features["suggested_level"],
                "feedback": feedback,
                "answer": answer_dict["answer"],       # <-- pass the answer string here
                "technique": answer_dict.get("technique", ""),  # pass technique separately
                "history": QuestionAnalysis.objects.order_by('-timestamp')[:5]
            }

    return render(request, 'qa/bq.html', context)
