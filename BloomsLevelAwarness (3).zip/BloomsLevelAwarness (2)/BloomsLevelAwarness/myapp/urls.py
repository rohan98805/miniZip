# users/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from .views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', base, name='base'),
    
    path('signup/', signup_view, name='signup'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    
    path('profile/', login_required(profile_view), name='profile'),
    path('profile/edit/', edit_profile, name='edit_profile'),
    
    path('password/', auth_views.PasswordChangeView.as_view(template_name='registration/change_password.html', success_url='/dashboard/'), name='change_password'),


    path('messages/', user_list_view, name='user_list'),
    path('messages/<int:user_id>/', chat_view_by_id, name='chat'),
    
    path('analyze_question/', analyze_question, name='analyze_question'),
    
    path('bloom_question_view/', bloom_question_view, name='bloom_question_view'),

    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

