from django.conf import settings
from django.db import models

class Message(models.Model):
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages')
    receiver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_messages', null=True, blank=True)
    text = models.TextField(blank=True)
    image = models.ImageField(upload_to='messages/', blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_group_message = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender} to {self.receiver or 'Group'}"

class Question(models.Model):
    text = models.TextField()
    bloom_level = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    answer_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

# models.py
from django.db import models

class QuestionAnalysis(models.Model):
    question_text = models.TextField(null=True, blank=True)
    predicted_level = models.CharField(max_length=50,null=True, blank=True)
    suggested_level = models.CharField(max_length=50, null=True, blank=True)
    matched_verbs = models.TextField(null=True, blank=True)
    tokens = models.TextField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)
    generated_answer = models.TextField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True, null=True, blank=True)

    def __str__(self):
        return f"{self.question_text[:50]}... - {self.predicted_level}"
