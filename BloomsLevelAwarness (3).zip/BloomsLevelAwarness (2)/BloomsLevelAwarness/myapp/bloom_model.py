from transformers import pipeline
from sympy import symbols, Eq, solve, sympify
import re
import spacy

# Load NLP model for feature extraction
nlp = spacy.load("en_core_web_sm")

# Load QA model for fallback answers
qa_model = pipeline("question-answering", model="deepset/roberta-base-squad2")

# Bloom level keywords
BLOOM_VERBS = {
    "Remember": ["define", "list", "recall", "name", "identify"],
    "Understand": ["describe", "explain", "summarize", "classify", "discuss"],
    "Apply": ["solve", "use", "implement", "demonstrate"],
    "Analyze": ["analyze", "compare", "contrast", "differentiate", "examine"],
    "Evaluate": ["evaluate", "justify", "critique", "argue"],
    "Create": ["design", "construct", "develop", "formulate", "invent"]
}


def predict_bloom_level(question):
    question = question.lower()
    if question.startswith("what is") or question.startswith("who is") or question.startswith("define"):
        return "Remember"
    for level, verbs in BLOOM_VERBS.items():
        for verb in verbs:
            if verb in question:
                return level
    return "Unclassified"



def extract_features(question):
    doc = nlp(question)
    tokens = [token.text for token in doc]
    verbs = [token.lemma_ for token in doc if token.pos_ == "VERB"]

    suggested_level = "Unclassified"
    for level, bloom_verbs in BLOOM_VERBS.items():
        if any(verb in bloom_verbs for verb in verbs):
            suggested_level = level
            break

    return {
        "tokens": tokens,
        "verbs": verbs,
        "suggested_level": suggested_level
    }


def give_feedback(features, predicted_level):
    if predicted_level == features["suggested_level"]:
        return f"Great! Your question matches the Bloom's level: {predicted_level}."
    else:
        return f"Consider rephrasing to better match the intended Bloom's level. Predicted: {predicted_level}, Suggested: {features['suggested_level']}."


def generate_nlp_answer(question):
    question_lower = question.lower()
    result = {
        "answer": "",
        "technique": ""
    }

    # Fallback answers
    fallback_answers = {
        "seven continents": ("Asia, Africa, North America, South America, Antarctica, Europe, and Australia.", ""),
        "capital of france": ("The capital of France is Paris.", ""),
        "capital of india": ("The capital of India is New Delhi.", ""),
        "gravity": ("Gravity is the force that attracts a body toward the center of the Earth or any other mass.", "This is based on Newton's law of universal gravitation."),
        "photosynthesis": ("Photosynthesis is the process by which green plants use sunlight to convert carbon dioxide and water into glucose and oxygen.", "It follows the chemical equation: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂."),
        "plant and animal cells": ("Plant cells have a cell wall and chloroplasts, whereas animal cells do not.", ""),
        "binary search": ("Binary search is an efficient algorithm for finding an item from a sorted list by repeatedly dividing the search interval in half.", "Technique: Divide and Conquer."),
        "ai in education": ("AI can improve education by enabling personalized learning, automating grading, and providing intelligent tutoring systems.", ""),
        "rocket works": ("A rocket works on Newton's third law. It expels gas backward, and the rocket moves forward due to the reaction force.", "Based on Newton's Third Law: For every action, there is an equal and opposite reaction."),
        "design a new app": ("An app to help students manage time can include a calendar, study timer, deadline reminders, and AI-based productivity suggestions.", "Use UI/UX principles, Pomodoro Technique, and notification APIs."),
        "time management app": ("Design an app with to-do lists, timers, calendar sync, study analytics, and motivational nudges.", ""),
         "computer": ("A computer is an electronic device that processes data and performs tasks according to instructions given by software.", ""),
        "internet": ("The internet is a global network of computers that communicate through standardized protocols.", ""),
        "python": ("Python is a high-level programming language known for its readability and wide range of applications.", ""),
        "machine learning": ("Machine learning is a branch of artificial intelligence that allows systems to learn and improve from data.", "")

    }

    for key, value in fallback_answers.items():
        if key in question_lower:
            result["answer"], result["technique"] = value
            return result

    # Algebraic equation solving
    # Try solving algebraic equations like "Solve x + 5 = 20"
        if "solve" in question_lower and "=" in question_lower:
            try:
                # This regex finds the equation after 'solve' ignoring extra words like 'the equation:'
                # It looks for an expression containing x and operators until '=' sign and the right side after '='
                match = re.search(r"solve(?:\s+the\s+equation:)?\s*([^\=]+)=\s*(.+)", question_lower)
                if match:
                    lhs_expr = match.group(1).strip()  # left side expression
                    rhs_expr = match.group(2).strip()  # right side expression

                    x = symbols('x')
                    lhs_sympy = sympify(lhs_expr.replace("^", "**"))
                    rhs_sympy = sympify(rhs_expr.replace("^", "**"))

                    sol = solve(Eq(lhs_sympy, rhs_sympy), x)
                    if sol:
                        return f"The solution is x = {sol[0]}"
                    else:
                        return "No solution found."
                else:
                    return "Could not parse the equation properly."
            except Exception as e:
                return f"⚠️ Error while solving equation: {str(e)}"

    # General QA model fallback
    context = """
    Gravity is the force that attracts a body toward the center of the Earth or any other mass.
    The seven continents are: Asia, Africa, North America, South America, Antarctica, Europe, and Australia.
    Paris is the capital of France. New Delhi is the capital of India.
    Photosynthesis is the process by which green plants use sunlight to synthesize food from CO2 and water.
    Binary search is an algorithm that finds a target in a sorted array by repeatedly dividing the search range in half.
    Plant cells have a cell wall and chloroplasts, animal cells do not.
    AI can improve education by enabling personalized learning and intelligent tutoring.
    A rocket works on Newton's third law. It pushes gas backward and moves forward.
    An app for student time management may include schedules, timers, reminders, and analytics.
    """

    try:
        qa_result = qa_model(question=question, context=context)
        if qa_result['score'] > 0.3:
            result["answer"] = qa_result['answer']
        else:
            result["answer"] = "🤖 I couldn't generate a meaningful answer. Please rephrase."
    except Exception as e:
        result["answer"] = f"⚠️ Error: {e}"

    return result
