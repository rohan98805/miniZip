from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class BootstrapFormMixin:
    """Mixin to add Bootstrap classes automatically."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            existing_class = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = existing_class + ' form-control'

class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name')  # Adjust as needed

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Username is already taken.")
        return username

class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']  # Only default User fields
        widgets = {
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
        }

# Question-related form remains unchanged
class QuestionForm(forms.Form):
    text = forms.CharField(
        widget=forms.Textarea(attrs={
            'placeholder': 'Type your question (one per line, prefix with Q:)...',
            'rows': 4,
            'class': 'form-control'
        }), label="Questions"
    )
    domain = forms.ChoiceField(
        choices=[('General','General'),('Science','Science'),('Math','Math'),('History','History')],
        widget=forms.Select(attrs={'class':'form-select'})
    )

from django import forms

class QuestionForm1(forms.Form):
    question = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), label="Enter your question")
    domain = forms.CharField(required=False, label="Domain (optional)")
