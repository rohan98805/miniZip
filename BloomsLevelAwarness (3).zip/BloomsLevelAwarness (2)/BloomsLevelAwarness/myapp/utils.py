import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from transformers import pipeline

# Download necessary NLTK resources
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Initialize lemmatizer
lemmatizer = WordNetLemmatizer()

# Define Bloom's Taxonomy Levels
BLOOM_VERBS = {
    "Remembering": ["list", "define", "name", "recall", "identify"],
    "Understanding": ["explain", "describe", "summarize", "interpret"],
    "Applying": ["use", "implement", "solve", "demonstrate"],
    "Analyzing": ["compare", "contrast", "examine", "differentiate"],
    "Evaluating": ["judge", "critique", "defend", "justify"],
    "Creating": ["design", "construct", "develop", "formulate"]
}

QUESTION_PATTERNS = {
    "Remembering": ["what is", "who is", "define", "list"],
    "Understanding": ["why", "how", "describe", "explain"],
    "Applying": ["how would you", "solve", "use"],
    "Analyzing": ["compare", "what are the differences", "analyze"],
    "Evaluating": ["do you agree", "justify", "critique"],
    "Creating": ["create", "design", "formulate", "propose"]
}

# Load a more suitable QA model
qa_model = pipeline("text2text-generation", model="google/flan-t5-base")

def split_questions(text):
    parts = re.split(r"Q: ?", text)
    return [p.strip() for p in parts if p.strip() and not p.startswith('Answer:')]

def predict_bloom_level(question):
    q = question.lower()
    for level, patterns in QUESTION_PATTERNS.items():
        if any(re.search(rf"\b{re.escape(p)}\b", q) for p in patterns):
            return level
    tokens = [lemmatizer.lemmatize(w) for w in word_tokenize(q.lower()) if w.isalpha()]
    for level, verbs in BLOOM_VERBS.items():
        if any(verb in tokens for verb in verbs):
            return level
    return "Uncertain"

def extract_features(question):
    q = question.lower()
    tokens = [lemmatizer.lemmatize(w) for w in word_tokenize(q) if w.isalpha() and w not in stopwords.words('english')]
    matched_level = "Uncertain"
    matched_verbs = []

    for level, verbs in BLOOM_VERBS.items():
        for verb in verbs:
            if verb in tokens:
                matched_level = level
                matched_verbs.append(verb)
                break

    for level, patterns in QUESTION_PATTERNS.items():
        if any(re.search(rf"\b{re.escape(p)}\b", q) for p in patterns):
            matched_level = level
            break

    return {"tokens": tokens, "verbs": matched_verbs, "suggested_level": matched_level}

def give_feedback(features, predicted_level, domain="General"):
    suggested = features["suggested_level"]
    if suggested != predicted_level and suggested != "Uncertain":
        return f"Your question seems '{suggested}', but was classified as '{predicted_level}'. Consider rephrasing for a clearer {predicted_level.lower()} focus."
    if predicted_level == "Remembering":
        return "Try asking a ‘why’ or ‘how’ question to move toward deeper understanding."
    if predicted_level == "Understanding":
        return "You can deepen learning by asking questions that apply or analyze the concept."
    return "Great! You're engaging at a higher-order thinking level."

def generate_nlp_answer(question, level, domain="General"):
    prompt = (f"You are a teaching assistant. Answer the following {level.lower()} level question "
              f"in the domain of {domain}:\n\nQ: {question}\nA:")
    resp = qa_model(prompt, max_new_tokens=100, num_return_sequences=1)
    return resp[0]['generated_text'].replace(prompt, '').strip()
