from transformers import pipeline
from sympy import symbols, Eq, solve, sympify
import re

# Load the QA model
qa_model = pipeline("question-answering", model="deepset/roberta-base-squad2")

def generate_nlp_answer(question):
    question_lower = question.lower()

    # Hardcoded fallback answers
    fallback_answers = {
        "seven continents": "Asia, Africa, North America, South America, Antarctica, Europe, and Australia.",
        "capital of france": "The capital of France is Paris.",
        "capital of india": "The capital of India is New Delhi.",
        "gravity": "Gravity is the force that attracts a body toward the center of the Earth or any other mass.",
        "photosynthesis": "Photosynthesis is the process by which green plants use sunlight to convert carbon dioxide and water into glucose and oxygen.",
        "plant and animal cells": "Plant cells have a cell wall and chloroplasts, whereas animal cells do not.",
        "binary search": "Binary search is an efficient algorithm for finding an item from a sorted list by repeatedly dividing the search interval in half.",
        "ai in education": "AI can improve education by enabling personalized learning, automating grading, and providing intelligent tutoring systems.",
        "rocket works": "A rocket works on Newton's third law. It expels gas backward, and the rocket moves forward due to the reaction force.",
        "design a new app": "An app to help students manage time can include a calendar, study timer, deadline reminders, and AI-based productivity suggestions.",
        "time management app": "Design an app with to-do lists, timers, calendar sync, study analytics, and motivational nudges."
    }

    for key in fallback_answers:
        if key in question_lower:
            return fallback_answers[key]

    # Try solving algebraic equations like "Solve x + 5 = 20"
    if "solve" in question_lower and "=" in question_lower:
        try:
            match = re.search(r"solve\s+(.*?)=", question_lower)
            if match:
                expr = match.group(1).strip()
                rhs = question_lower.split("=")[-1].strip()
                x = symbols('x')
                lhs_expr = sympify(expr.replace("^", "**"))
                rhs_expr = sympify(rhs.replace("^", "**"))
                sol = solve(Eq(lhs_expr, rhs_expr), x)
                if sol:
                    return f"The solution is x = {sol[0]}"
                else:
                    return "No solution found."
        except Exception as e:
            return f"⚠️ Error while solving equation: {str(e)}"

    # General QA model fallback
    context = """
    Gravity is the force that attracts a body toward the center of the Earth or any other mass.
    The seven continents are: Asia, Africa, North America, South America, Antarctica, Europe, and Australia.
    Paris is the capital of France. New Delhi is the capital of India.
    Photosynthesis is the process by which green plants use sunlight to synthesize food from CO2 and water.
    Binary search is an algorithm that finds a target in a sorted array by repeatedly dividing the search range in half.
    Plant cells have a cell wall and chloroplasts, animal cells do not.
    AI can improve education by enabling personalized learning and intelligent tutoring.
    A rocket works on Newton's third law. It pushes gas backward and moves forward.
    An app for student time management may include schedules, timers, reminders, and analytics.
    """

    try:
        result = qa_model(question=question, context=context)
        if result['score'] > 0.3:
            return result['answer']
        else:
            return "🤖 I couldn't generate a meaningful answer. Please rephrase."
    except Exception as e:
        return f"⚠️ Error: {e}"

# Test questions
questions = [
    "Define gravity.",
    "List the seven continents.",
    "Solve the equation: x + 5 = 20.",
    "Compare plant and animal cells.",
    "What is the capital of France?",
    "How would you implement a binary search algorithm?",
    "Do you agree with the use of AI in education? Justify your answer.",
    "Design a new app to help students manage time.",
    "Explain how a rocket works.",
    "What is photosynthesis?"
]

for q in questions:
    print(f"Q: {q}")
    print("A:", generate_nlp_answer(q))
    print("=" * 50)
